var sensorData = [];
module.exports = {
  sensorData
}